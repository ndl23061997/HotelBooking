var express = require('express');
var router = express.Router();
var adminModel = require('../../models/admin/admin');

router.use(checkLogin);

router.get('/', (req, res, next) => {
    res.render('admin/index/index');
})

// Kiem tra thong tin dang nhap. Neu dang nhập rồi thì tiếp tục kiểm tra xem tài khoản đăng nhập có phải tài khoản quản trị không
function checkLogin(req, res, next) {
    if (req.isAuthenticated()) {
        console.log("Loai tai khoan", req.session.passport.user)
        if(req.session.passport.user.type == 0) {
            next();
        } else {
            res.redirect('/login');
        }
        
    } else {
        res.redirect('/login');
    }
}
module.exports = router;
